package com.example.gtvmirror;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Surface;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Test implementation. Requires user consent for EACH screen capture session. */
public final class CaptureService extends Service {
    static final String START = "com.example.gtvmirror.START";
    static final String STOP = "com.example.gtvmirror.STOP";
    static final String EXTRA_DATA = "capture_data";
    static final String EXTRA_RESULT = "capture_result";
    static final String EXTRA_PIN = "pair_pin";
    static final String EXTRA_HIGH = "high_quality";

    private static final String TAG = "GTVMirrorCapture";
    private static final String CHANNEL = "mirror_capture";
    private static final int NOTIFICATION_ID = 101;
    private volatile boolean running = false;
    private String pin;
    private int width, height;
    private volatile CodecInfo codecInfo;
    private final Object codecLock = new Object();
    private volatile MirrorClient activeClient;
    private ServerSocket serverSocket;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private MediaCodec encoder;
    private Surface encoderSurface;
    private Thread acceptThread, encodeThread;
    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() { stopSelf(); }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!START.equals(intent.getAction()) || running) return START_NOT_STICKY;

        final Intent token;
        if (Build.VERSION.SDK_INT >= 33) {
            token = intent.getParcelableExtra(EXTRA_DATA, Intent.class);
        } else {
            token = intent.getParcelableExtra(EXTRA_DATA);
        }
        if (token == null) { stopSelf(); return START_NOT_STICKY; }
        final int result = intent.getIntExtra(EXTRA_RESULT, 0);
        pin = intent.getStringExtra(EXTRA_PIN);
        boolean high = intent.getBooleanExtra(EXTRA_HIGH, false);
        width = high ? 1920 : 1280;
        height = high ? 1080 : 720;
        if (pin == null || !pin.matches("[0-9]{6}")) { stopSelf(); return START_NOT_STICKY; }

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "屏幕镜像发送", NotificationManager.IMPORTANCE_LOW));
        Intent stopIntent = new Intent(this, CaptureService.class).setAction(STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 7, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent openPi = PendingIntent.getActivity(this, 8, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification note = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Google TV Mirror 正在共享画面")
                .setContentText("手机端输入电视IP与6位配对码")
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "停止镜像", stopPi).build())
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, note);
        }
        running = true;
        new Thread(() -> {
            try { startPipeline(result, token); }
            catch (Throwable ex) {
                Log.e(TAG, "无法启动屏幕捕获", ex);
                stopSelf();
            }
        }, "capture-start").start();
        return START_NOT_STICKY;
    }

    private void startPipeline(int result, Intent token) throws Exception {
        MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mgr.getMediaProjection(result, token);
        if (projection == null || !running) throw new IllegalStateException("没有屏幕捕获授权");
        projection.registerCallback(projectionCallback, new Handler(Looper.getMainLooper()));

        MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, width == 1920 ? 5000000 : 3000000);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        format.setInteger(MediaFormat.KEY_PRIORITY, 0);
        encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        encoderSurface = encoder.createInputSurface();
        encoder.start();
        // A media projection token may only be used once for createVirtualDisplay on Android 14+.
        int density = getResources().getDisplayMetrics().densityDpi;
        virtualDisplay = projection.createVirtualDisplay("GTVMirror", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, encoderSurface, null, null);
        encodeThread = new Thread(this::encodeLoop, "h264-encode");
        encodeThread.start();
        acceptThread = new Thread(this::acceptLoop, "tcp-server");
        acceptThread.start();
    }

    private void encodeLoop() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        try {
            while (running && !Thread.currentThread().isInterrupted()) {
                MediaCodec current = encoder;
                if (current == null) break;
                int idx = current.dequeueOutputBuffer(info, 10000);
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat output = current.getOutputFormat();
                    synchronized (codecLock) {
                        codecInfo = new CodecInfo(getBytes(output, "csd-0"), getBytes(output, "csd-1"));
                        codecLock.notifyAll();
                    }
                } else if (idx >= 0) {
                    if (info.size > 0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        ByteBuffer bb = current.getOutputBuffer(idx);
                        if (bb != null) {
                            bb.position(info.offset);
                            bb.limit(info.offset + info.size);
                            byte[] data = new byte[info.size];
                            bb.get(data);
                            MirrorClient client = activeClient;
                            if (client != null) client.enqueue(new VideoPacket(data, info.presentationTimeUs, info.flags));
                        }
                    }
                    current.releaseOutputBuffer(idx, false);
                }
            }
        } catch (Exception e) { if (running) Log.e(TAG, "视频编码线程失败", e); }
    }

    private static byte[] getBytes(MediaFormat f, String name) {
        ByteBuffer bb = f.getByteBuffer(name);
        if (bb == null) return new byte[0];
        bb = bb.duplicate();
        byte[] bytes = new byte[bb.remaining()];
        bb.get(bytes);
        return bytes;
    }

    private void requestKeyFrame() {
        MediaCodec c = encoder;
        if (c == null) return;
        try {
            Bundle args = new Bundle();
            args.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
            c.setParameters(args);
        } catch (Exception ex) { Log.w(TAG, "请求关键帧失败", ex); }
    }

    private void acceptLoop() {
        try (ServerSocket server = new ServerSocket(NetUtil.PORT)) {
            serverSocket = server;
            server.setReuseAddress(true);
            while (running) {
                Socket socket = server.accept();
                socket.setTcpNoDelay(true);
                socket.setSoTimeout(8000);
                new Thread(() -> serve(socket), "mirror-client").start();
            }
        } catch (IOException e) { if (running) Log.e(TAG, "监听端口失败", e); }
    }

    private void serve(Socket socket) {
        MirrorClient client = null;
        try (Socket autoClose = socket;
             DataInputStream in = new DataInputStream(socket.getInputStream());
             DataOutputStream out = new DataOutputStream(socket.getOutputStream())) {
            String supplied = in.readUTF();
            if (!pin.equals(supplied)) {
                out.writeByte(0); out.flush(); return;
            }
            synchronized (this) {
                if (activeClient != null) {
                    out.writeByte(2); out.flush(); return;
                }
                client = new MirrorClient();
                activeClient = client;
            }
            CodecInfo codecs;
            synchronized (codecLock) {
                long end = System.currentTimeMillis() + 8000;
                while (running && codecInfo == null && System.currentTimeMillis() < end) {
                    codecLock.wait(200);
                }
                codecs = codecInfo;
            }
            if (codecs == null) throw new IOException("编码器未准备好");
            out.writeByte(1);
            out.writeInt(0x47545631); // GTV1
            out.writeInt(width);
            out.writeInt(height);
            out.writeInt(codecs.sps.length);
            out.write(codecs.sps);
            out.writeInt(codecs.pps.length);
            out.write(codecs.pps);
            out.flush();
            socket.setSoTimeout(0);
            requestKeyFrame();
            while (running && !socket.isClosed()) {
                VideoPacket frame = client.queue.poll(2, TimeUnit.SECONDS);
                if (frame == null) continue;
                out.writeInt(frame.data.length);
                out.writeLong(frame.ptsUs);
                out.writeInt(frame.flags);
                out.write(frame.data);
                // TCP_NODELAY avoids waiting for small packet coalescing.
                out.flush();
            }
        } catch (Exception e) { if (running) Log.i(TAG, "手机端断开: " + e.getMessage()); }
        finally {
            synchronized (this) { if (activeClient == client) activeClient = null; }
            if (client != null) client.queue.clear();
        }
    }

    @Override public void onDestroy() {
        running = false;
        synchronized (codecLock) { codecLock.notifyAll(); }
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) {}
        MirrorClient client = activeClient;
        if (client != null) client.queue.clear();
        if (acceptThread != null) acceptThread.interrupt();
        if (encodeThread != null) encodeThread.interrupt();
        // Dispose of media objects after the encoder loop is no longer using them.
        new Thread(() -> {
            try { if (encodeThread != null) encodeThread.join(1000); } catch (InterruptedException ignored) {}
            try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
            try { if (encoder != null) encoder.stop(); } catch (Exception ignored) {}
            try { if (encoder != null) encoder.release(); } catch (Exception ignored) {}
            try { if (encoderSurface != null) encoderSurface.release(); } catch (Exception ignored) {}
            try { if (projection != null) projection.unregisterCallback(projectionCallback); } catch (Exception ignored) {}
            try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        }, "capture-release").start();
        super.onDestroy();
    }

    private static final class CodecInfo {
        final byte[] sps, pps;
        CodecInfo(byte[] sps, byte[] pps) { this.sps = sps; this.pps = pps; }
    }
    private static final class VideoPacket {
        final byte[] data;
        final long ptsUs;
        final int flags;
        VideoPacket(byte[] data, long ptsUs, int flags) {
            this.data = data; this.ptsUs = ptsUs; this.flags = flags;
        }
    }
    private final class MirrorClient {
        final ArrayBlockingQueue<VideoPacket> queue = new ArrayBlockingQueue<>(7);
        private boolean awaitingKeyFrame = true;
        synchronized void enqueue(VideoPacket frame) {
            boolean key = (frame.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
            if (awaitingKeyFrame) {
                if (!key) return;
                awaitingKeyFrame = false;
            }
            if (!queue.offer(frame)) {
                queue.clear();
                awaitingKeyFrame = true;
                requestKeyFrame();
            }
        }
    }
}
