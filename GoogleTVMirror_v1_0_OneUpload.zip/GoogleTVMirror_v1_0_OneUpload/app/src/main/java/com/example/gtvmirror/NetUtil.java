package com.example.gtvmirror;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

final class NetUtil {
    static final int PORT = 18765;
    private NetUtil() {}

    static String localIpv4() {
        try {
            String fallback = null;
            for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!n.isUp() || n.isLoopback()) continue;
                for (InetAddress a : Collections.list(n.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        String ip = a.getHostAddress();
                        if (n.getName().startsWith("wlan") || n.getName().startsWith("eth")) return ip;
                        if (a.isSiteLocalAddress()) fallback = ip;
                    }
                }
            }
            return fallback == null ? "未找到局域网地址" : fallback;
        } catch (Exception e) { return "无法读取IP: " + e.getMessage(); }
    }
}
