package com.example.gtvmirror;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Build;
import android.util.Log;
import android.view.Surface;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;

/** Receives framed H.264 samples and renders them via hardware MediaCodec. */
final class StreamReceiver {
    interface Listener {
        void onState(String state);
        void onSize(int width, int height);
        void onStopped();
    }

    private static final String TAG = "GTVMirrorReceive";
    private final String ip, pin;
    private final Listener listener;
    private final Object surfaceLock = new Object();
    private volatile boolean running;
    private volatile Surface surface;
    private volatile Socket socket;
    private Thread thread;

    StreamReceiver(String ip, String pin, Listener listener) {
        this.ip = ip.trim(); this.pin = pin.trim(); this.listener = listener;
    }

    void attachSurface(Surface newSurface) {
        synchronized (surfaceLock) {
            surface = newSurface;
            surfaceLock.notifyAll();
        }
    }

    void start() {
        if (running) return;
        running = true;
        thread = new Thread(this::connectAndDecode, "h264-receive");
        thread.start();
    }

    void stop() {
        running = false;
        synchronized (surfaceLock) { surfaceLock.notifyAll(); }
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        if (thread != null) thread.interrupt();
    }

    private void connectAndDecode() {
        MediaCodec decoder = null;
        try (Socket sock = new Socket()) {
            socket = sock;
            listener.onState("正在连接电视端…");
            sock.connect(new InetSocketAddress(ip, NetUtil.PORT), 4500);
            sock.setTcpNoDelay(true);
            sock.setSoTimeout(12000);
            DataInputStream in = new DataInputStream(sock.getInputStream());
            DataOutputStream out = new DataOutputStream(sock.getOutputStream());
            out.writeUTF(pin);
            out.flush();
            int status = in.readUnsignedByte();
            if (status == 0) throw new Exception("配对码不正确");
            if (status == 2) throw new Exception("电视正在被另一台手机连接");
            if (status != 1) throw new Exception("协议验证失败");
            if (in.readInt() != 0x47545631) throw new Exception("不兼容的视频传输协议");
            int w = in.readInt();
            int h = in.readInt();
            if (w <= 0 || w > 3840 || h <= 0 || h > 2160) throw new Exception("视频尺寸无效");
            byte[] csd0 = readParameterSet(in);
            byte[] csd1 = readParameterSet(in);
            listener.onSize(w, h);
            listener.onState("连接成功，正在启动硬件解码…");

            Surface output;
            synchronized (surfaceLock) {
                while (running && (surface == null || !surface.isValid())) surfaceLock.wait(300);
                output = surface;
            }
            if (!running) return;
            MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
            if (csd0.length > 0) f.setByteBuffer("csd-0", ByteBuffer.wrap(csd0));
            if (csd1.length > 0) f.setByteBuffer("csd-1", ByteBuffer.wrap(csd1));
            if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
            decoder = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            try {
                decoder.configure(f, output, null, 0);
            } catch (Exception lowLatencyNotSupported) {
                // Some hardware advertises an API but cannot enable low-latency mode.
                decoder.release();
                decoder = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
                f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
                if (csd0.length > 0) f.setByteBuffer("csd-0", ByteBuffer.wrap(csd0));
                if (csd1.length > 0) f.setByteBuffer("csd-1", ByteBuffer.wrap(csd1));
                decoder.configure(f, output, null, 0);
            }
            decoder.start();
            listener.onState("镜像中 · " + w + " × " + h + " / H.264");
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            long frames = 0;
            long tick = System.currentTimeMillis();
            while (running) {
                int n = in.readInt();
                if (n <= 0 || n > 8 * 1024 * 1024) throw new Exception("收到异常视频包");
                long ptsUs = in.readLong();
                in.readInt(); // encoder flags, decoder doesn't need these
                byte[] frame = new byte[n];
                in.readFully(frame);
                int index = -1;
                while (running && index < 0) {
                    index = decoder.dequeueInputBuffer(10000);
                    drain(decoder, info);
                }
                if (!running) break;
                ByteBuffer inputBuffer = decoder.getInputBuffer(index);
                if (inputBuffer == null) throw new Exception("解码输入缓冲区不可用");
                inputBuffer.clear();
                if (n > inputBuffer.remaining()) throw new Exception("解码器输入缓冲区容量不足");
                inputBuffer.put(frame);
                decoder.queueInputBuffer(index, 0, n, ptsUs, 0);
                drain(decoder, info);
                frames++;
                long now = System.currentTimeMillis();
                if (now - tick >= 5000) {
                    final long fps = Math.round(frames * 1000.0 / (now - tick));
                    listener.onState("镜像中 · 实际接收 " + fps + " FPS");
                    frames = 0;
                    tick = now;
                }
            }
        } catch (Exception e) {
            if (running) {
                Log.e(TAG, "镜像连接中断", e);
                listener.onState("连接失败或断开：" + e.getMessage());
            }
        } finally {
            running = false;
            if (decoder != null) {
                try { decoder.stop(); } catch (Exception ignored) {}
                try { decoder.release(); } catch (Exception ignored) {}
            }
            socket = null;
            listener.onStopped();
        }
    }

    private static void drain(MediaCodec codec, MediaCodec.BufferInfo info) {
        while (true) {
            int idx = codec.dequeueOutputBuffer(info, 0);
            if (idx >= 0) codec.releaseOutputBuffer(idx, true);
            else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) continue;
            else break;
        }
    }

    private static byte[] readParameterSet(DataInputStream in) throws Exception {
        int n = in.readInt();
        if (n < 0 || n > 4096) throw new Exception("H.264参数错误");
        byte[] result = new byte[n];
        in.readFully(result);
        return result;
    }
}
