package com.example.gtvmirror;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.content.pm.ActivityInfo;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.security.SecureRandom;

public final class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 901;
    private static final int BG = Color.rgb(10, 18, 32);
    private static final int FG = Color.rgb(236, 247, 255);
    private static final int SUB = Color.rgb(154, 171, 195);
    private static final int BLUE = Color.rgb(16, 122, 205);

    private StreamReceiver receiver;
    private FrameLayout playerRoot;
    private SurfaceView playerSurface;
    private TextView playerStatus;
    private boolean watching = false;
    private boolean highQuality = false;
    private String pairingCode;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        pairingCode = getPreferences(MODE_PRIVATE).getString("pin", "------");
        showHome();
    }

    private GradientDrawable shape(int background, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(background);
        drawable.setCornerRadius(dp(13));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }
    private int dp(int d) { return Math.round(d * getResources().getDisplayMetrics().density); }
    private TextView label(String content, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(content);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }
    private LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(top);
        return p;
    }
    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(17);
        b.setAllCaps(false);
        b.setMinHeight(dp(54));
        b.setBackground(shape(color, BLUE));
        b.setFocusable(true);
        return b;
    }
    private void addText(LinearLayout parent, String t, int size, int color, boolean bold, int gap) {
        parent.addView(label(t, size, color, bold), lp(gap));
    }

    private void showHome() {
        watching = false;
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(24), dp(24), dp(24), dp(40));
        scroll.addView(pane);
        setContentView(scroll);
        addText(pane, "Google TV Mirror", 28, FG, true, 0);
        addText(pane, "电视画面 → 手机 · 低延迟局域网镜像", 15, SUB, false, 5);
        boolean isTv = getPackageManager().hasSystemFeature(PackageManager.FEATURE_LEANBACK);
        addText(pane, isTv ? "① 电视端 · 发送画面" : "① 如果这里是 Google TV，点击下方启动", 21, FG, true, 30);
        addText(pane, "电视局域网 IP", 14, SUB, false, 15);
        addText(pane, NetUtil.localIpv4() + " : " + NetUtil.PORT, 22, FG, true, 5);
        addText(pane, "手机配对码", 14, SUB, false, 15);
        addText(pane, pairingCode, 32, FG, true, 5);
        addText(pane, "开始后，在系统弹窗选择共享整个屏幕并允许。然后按遥控器主页键，镜像不会自动停止。", 14, SUB, false, 10);
        Button low = button("开始发送 · 720p / 30 FPS（推荐低延迟）", BLUE);
        pane.addView(low, lp(15));
        low.setOnClickListener(v -> requestCapture(false));
        Button high = button("开始发送 · 1080p / 30 FPS", Color.rgb(40, 66, 96));
        pane.addView(high, lp(12));
        high.setOnClickListener(v -> requestCapture(true));
        Button stop = button("停止电视端镜像", Color.rgb(80, 46, 56));
        pane.addView(stop, lp(12));
        stop.setOnClickListener(v -> {
            startService(new Intent(this, CaptureService.class).setAction(CaptureService.STOP));
            addText(pane, "已发送停止指令", 14, SUB, false, 8);
        });

        addText(pane, "② 手机端 · 接收画面", 21, FG, true, 32);
        addText(pane, "手机和 Google TV 必须连接同一路由器／局域网。", 14, SUB, false, 8);
        EditText ip = new EditText(this);
        ip.setSingleLine(true);
        ip.setTextColor(FG);
        ip.setHintTextColor(SUB);
        ip.setHint("电视 IP，例如 192.168.1.40");
        ip.setText(getPreferences(MODE_PRIVATE).getString("last_ip", ""));
        ip.setBackground(shape(Color.rgb(24, 39, 60), BLUE));
        ip.setPadding(dp(14), dp(12), dp(14), dp(12));
        pane.addView(ip, lp(15));
        EditText pin = new EditText(this);
        pin.setSingleLine(true);
        pin.setTextColor(FG);
        pin.setHintTextColor(SUB);
        pin.setHint("电视显示的 6 位配对码");
        pin.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        pin.setBackground(shape(Color.rgb(24, 39, 60), BLUE));
        pin.setPadding(dp(14), dp(12), dp(14), dp(12));
        pane.addView(pin, lp(12));
        Button connect = button("连接 Google TV → 全屏镜像", BLUE);
        pane.addView(connect, lp(15));
        connect.setOnClickListener(v -> {
            String addr = ip.getText().toString().trim();
            String code = pin.getText().toString().trim();
            if (addr.length() < 7 || !code.matches("[0-9]{6}")) {
                pin.setError("请输入电视 IP 与6位数字配对码"); return;
            }
            getPreferences(MODE_PRIVATE).edit().putString("last_ip", addr).apply();
            showPlayer(addr, code);
        });
        addText(pane, "测试版：仅传输画面，不含声音或远程操控；受保护的视频可能黑屏。", 13, SUB, false, 22);
    }

    private void requestCapture(boolean high) {
        highQuality = high;
        try {
            MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mgr.createScreenCaptureIntent(), CAPTURE_REQUEST);
        } catch (Exception e) {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("电视系统不支持启动屏幕捕获")
                    .setMessage("Google TV 可能未提供标准 MediaProjection 授权界面：" + e.getMessage()
                            + "\n可尝试通过 scrcpy/ADB 方案镜像，但普通App不能绕过系统授权。")
                    .setPositiveButton("确定", null).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAPTURE_REQUEST) return;
        if (resultCode != RESULT_OK || data == null) {
            new android.app.AlertDialog.Builder(this).setMessage("屏幕共享未授权，无法发送镜像。")
                    .setPositiveButton("确定", null).show();
            return;
        }
        pairingCode = String.format(java.util.Locale.US, "%06d", new SecureRandom().nextInt(1000000));
        getPreferences(MODE_PRIVATE).edit().putString("pin", pairingCode).apply();
        Intent i = new Intent(this, CaptureService.class).setAction(CaptureService.START);
        i.putExtra(CaptureService.EXTRA_DATA, data);
        i.putExtra(CaptureService.EXTRA_RESULT, resultCode);
        i.putExtra(CaptureService.EXTRA_PIN, pairingCode);
        i.putExtra(CaptureService.EXTRA_HIGH, highQuality);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        showHome();
    }

    private void showPlayer(String ip, String pin) {
        watching = true;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        playerRoot = new FrameLayout(this);
        playerRoot.setBackgroundColor(Color.BLACK);
        playerSurface = new SurfaceView(this);
        FrameLayout.LayoutParams surfP = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        playerRoot.addView(playerSurface, surfP);
        playerStatus = label("连接准备中…", 13, FG, false);
        playerStatus.setPadding(dp(12), dp(7), dp(12), dp(7));
        playerStatus.setBackground(shape(0x990B1424, 0x55223344));
        FrameLayout.LayoutParams statusP = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        statusP.setMargins(dp(12), 0, 0, dp(14));
        playerRoot.addView(playerStatus, statusP);
        Button close = button("退出镜像", Color.rgb(68, 51, 65));
        close.setTextSize(12);
        FrameLayout.LayoutParams closeP = new FrameLayout.LayoutParams(dp(118), dp(52), Gravity.RIGHT | Gravity.TOP);
        closeP.setMargins(0, dp(10), dp(12), 0);
        playerRoot.addView(close, closeP);
        close.setOnClickListener(v -> stopWatching());
        setContentView(playerRoot);
        receiver = new StreamReceiver(ip, pin, new StreamReceiver.Listener() {
            @Override public void onState(String state) {
                runOnUiThread(() -> { if (watching) playerStatus.setText(state); });
            }
            @Override public void onSize(int w, int h) {
                runOnUiThread(() -> {
                    if (watching && playerRoot != null) {
                        playerRoot.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or2,ob) -> resizeSurface(w, h));
                        resizeSurface(w, h);
                    }
                });
            }
            @Override public void onStopped() {
                // Keep the failure status visible so the user can diagnose connection issues.
            }
        });
        playerSurface.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override public void surfaceCreated(SurfaceHolder holder) {
                if (receiver != null) receiver.attachSurface(holder.getSurface());
            }
            @Override public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}
            @Override public void surfaceDestroyed(SurfaceHolder holder) {
                if (receiver != null) receiver.attachSurface(null);
            }
        });
        if (playerSurface.getHolder().getSurface().isValid())
            receiver.attachSurface(playerSurface.getHolder().getSurface());
        receiver.start();
    }

    private void resizeSurface(int w, int h) {
        if (playerRoot == null || playerSurface == null) return;
        int pw = playerRoot.getWidth(), ph = playerRoot.getHeight();
        if (pw <= 0 || ph <= 0) return;
        float scale = Math.min(pw / (float) w, ph / (float) h);
        int sw = Math.round(w * scale), sh = Math.round(h * scale);
        ViewGroup.LayoutParams old = playerSurface.getLayoutParams();
        if (old.width == sw && old.height == sh) return;
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(sw, sh, Gravity.CENTER);
        playerSurface.setLayoutParams(p);
    }

    private void stopWatching() {
        watching = false;
        if (receiver != null) { receiver.stop(); receiver = null; }
        playerRoot = null;
        playerSurface = null;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        getWindow().getDecorView().setSystemUiVisibility(0);
        showHome();
    }
    @Override public void onBackPressed() {
        if (watching) stopWatching(); else super.onBackPressed();
    }
    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
    @Override protected void onDestroy() {
        if (receiver != null) receiver.stop();
        super.onDestroy();
    }
}
