# Google TV Mirror v1.0 (技术测试版)

**用途：将 Google TV / Android TV 的当前屏幕通过本地网络低延迟镜像到 Android 手机。**

## 设计要点

- **同一个 APK**，同时安装在 Google TV 盒子和安卓手机。
- 电视端使用 Android `MediaProjection` 申请屏幕捕获授权，将画面编码为 H.264。
- 720p 30FPS / 3Mbps（推荐低延迟），或 1080p 30FPS / 5Mbps。
- 局域网 TCP（18765 端口），无云端中转；手机端使用 MediaCodec 硬件视频解码。
- 6 位配对码，限制同时只有 1 个接收连接。
- UI 用中文适配电视遥控器与手机触控。
- 视频画面按 16:9 比例显示，手机进入横屏。

## 必须先了解的限制

- Google TV 设备 **不保证** 提供标准 MediaProjection 同意对话框。实际 Google TV Streamer (4K) 上是否能共享整个画面，需真机验证。
- 每次启动共享必须得到系统授权，不能用普通应用跳过系统权限。
- DRM 及 `FLAG_SECURE` 保护的视频/应用可能黑屏，无法绕过保护。
- 本版 **无声音、无触控反向操控、无互联网中继**。
- **未在真实 Google TV Streamer (4K) 上测试，未在本环境编译 APK**。这是供 Github Actions 编译测试的原生 Android 工程，不是已验证正式产品。
- 配对码及视频流目前**没有加密**，只应在自己可信任的家庭局域网中使用。不要向公网暴露 TCP 18765。
- Android 8+，使用 Google TV / Android TV 盒子时仍需要允许通过 APK 安装应用。

## 编译（推荐 GitHub Actions）

1. 解压本项目 ZIP。
2. 新建 GitHub 仓库，将解压后根目录的所有文件和 `.github/workflows/build-apk.yml` 上传到仓库根目录，提交到 `main`。
3. 打开仓库 `Actions` → `Build Google TV Mirror APK` → `Run workflow`（或者等 push 自动触发）。
4. 构建成功后，打开该次 Actions 运行 → `Artifacts` → `GoogleTVMirror-v1.0-debug-APK` 下载 ZIP 并解压获得 `app-debug.apk`。
5. 将**同一个 APK**安装到 Google TV Streamer (4K) 和安卓手机。

也可 Android Studio 打开项目后执行 `assembleDebug`。项目在 GitHub Actions 中使用 JDK 17、Gradle 8.9、Android Gradle Plugin 8.7.3、compileSdk 35。

## 使用

1. 电视和手机连同一个路由器／局域网。禁止路由器“AP 隔离 / 客户端隔离”。
2. Google TV 上打开 **Google TV Mirror**，按 **开始发送 · 720p**。
3. 当电视系统弹出录屏授权窗口时，选择 **共享整个屏幕**、允许。系统若未提供授权窗口，则本方案在该盒子上暂时不可用。
4. 返回主界面，记下电视显示的局域网 IP 和 **6 位配对码**。
5. 手机打开同一 App，在“手机端接收”输入 IP 和配对码，按 **连接 Google TV → 全屏镜像**。
6. 画面开始后，可按电视遥控器 `Home` 离开本 App，屏幕分享应继续通过前台服务进行；从电视端 App 或通知中点停止结束。

## 排障

- **无法启动录屏授权**：Google TV 系统限制此 API；此 App 无法自行绕过。
- **无法连接**：确认网络互通、IP 正确、配对码是最新一次启动生成的、路由器没有 AP 隔离、TCP 18765 未被阻止。
- **连接后黑屏**：先在 Google TV 主界面或系统设置测试。若只有 Netflix 等应用黑屏，可能是 DRM/安全保护。
- **花屏、跳帧**：选 720p，电视尽可能使用以太网线或 5GHz Wi-Fi；手机连 5GHz，少用拥堵的 2.4GHz。
- **几秒后断开**：检查电视有没有关闭前台服务、待机或局域网断开；可通过 Android Studio `adb logcat -s GTVMirrorCapture GTVMirrorReceive` 查看日志。
- **没有声音 / 不能遥控**：本测试版未开发这些功能，不是设置问题。

## 协议简述

手机端在 TCP 18765 连接电视，使用 DataOutputStream `writeUTF(6-digit PIN)` 握手。电视回 1 字节状态：0=失败，1=成功，2=已有客户端。成功时依次发送 magic `GTV1`（int32）、宽和高（int32）、SPS/PPS（int32 长度 + 字节）。之后逐帧写 int32 长度、int64 PTS(µs)、int32 flags、H.264 encoded access unit。大多数 Android 硬件编解码组合可直接接收，仍需要设备测试。无加密。

## 隐私与合法使用

本软件需要得到屏幕分享人的系统授权，不会静默开启截屏。不应捕获无权共享的第三方内容或试图绕过 DRM；仅在可信任局域网使用。
